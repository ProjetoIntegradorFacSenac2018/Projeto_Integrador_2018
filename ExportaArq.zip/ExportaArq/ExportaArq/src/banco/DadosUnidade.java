/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banco;

import ExportaArqs.Unidade;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class DadosUnidade {

    public static int insereUnidade(Connection bdConnection, Unidade i) {
        if (bdConnection == null) {
            return -1;
        }
        PreparedStatement stmt = null;
        try {
            // prepara comando a ser executado pelo BD
            stmt = bdConnection.prepareStatement(
                    "INSERT INTO tb_unidade (un_vend_prod, Desc_unid) VALUES (?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, i.getUn_vend_prod());
            stmt.setString(2, i.getDesc_unid());
            // executa comando
            stmt.executeUpdate();
            // obtem chave gerada para o registro inserido
//            int id = -1;
//            ResultSet rsID = stmt.getGeneratedKeys();
//            if (rsID.next()) {
//                id = rsID.getInt("id");
//            }
            stmt.close();
//            return id;

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao inserir Dados Unidade de vendas na base de dados\n" + ex.getMessage(),
                    "Inserir unidade de vendas", JOptionPane.ERROR_MESSAGE);
            return -1; //indica erro
        }
        return -1;
    }
}
