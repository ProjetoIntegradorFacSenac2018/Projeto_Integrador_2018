/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banco;

import ExportaArqs.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class DadosClientes {

    public static int insereClientes(Connection bdConnection, Cliente i) {
        if (bdConnection == null) {
            return -1;
        }
        PreparedStatement stmt = null;
        try {
            // prepara comando a ser executado pelo BD
            stmt = bdConnection.prepareStatement(
                    "INSERT INTO tb_cliente (cod_cliente, nome_cli, cpf_cli, cep_cli, "
                    + "endereco_cli, cidade_cli, uf_cli) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, Integer.parseInt(i.getId_cliente()));
            stmt.setString(2, i.getNome_cli());
            stmt.setString(3, i.getCpf_cli());
            stmt.setString(4, i.getCep_cli());
            stmt.setString(5, i.getEndereco_cli());
            stmt.setString(6, i.getCidade_cli());
            stmt.setString(7, i.getUf_cli());
            // executa comando
            stmt.executeUpdate();
            // obtem chave gerada para o registro inserido
//            int id = -1;
//            ResultSet rsID = stmt.getGeneratedKeys();
//            if (rsID.next()) {
//                id = rsID.getInt("id");
//            }
            stmt.close();
//            return id;

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao inserir Dados de clientes na base de dados\n" + ex.getMessage(),
                    "Inserir dados de clientes", JOptionPane.ERROR_MESSAGE);
            return -1; //indica erro
        }
        return -1;
    }
}
