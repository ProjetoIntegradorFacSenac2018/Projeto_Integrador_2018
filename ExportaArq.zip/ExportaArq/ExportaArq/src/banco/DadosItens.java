/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banco;

import ExportaArqs.Item;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class DadosItens {

    public static int insereItem(Connection bdConnection, Item i) {

        if (bdConnection == null) {
            return -1;
        }
        PreparedStatement stmt = null;
        try {
            // prepara comando a ser executado pelo BD
            stmt = bdConnection.prepareStatement(
                    "INSERT INTO tb_item (nr_nf, cod_prod, qtd_item, vlr_desc_item) VALUES (?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1,  Integer.parseInt(i.getNr_nf()));
            stmt.setInt(2,  Integer.parseInt(i.getId_produto()));
//            stmt.setDouble(3,  Double.parseDouble(i.getQtd_item()));
            stmt.setDouble(3, Double.parseDouble(i.getQtd_item().trim().replaceAll(",", ".")));

            stmt.setDouble(4, 0);

            // executa comando
            stmt.executeUpdate();
            // obtem chave gerada para o registro inserido
//            int id = -1;
//            ResultSet rsID = stmt.getGeneratedKeys();
//            if (rsID.next()) {
//                id = rsID.getInt("id");
//            }
            stmt.close();
//            return id;

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao inserir dados de itens na base de dados\n" + ex.getMessage(),
                    "Inserir dados de itens", JOptionPane.ERROR_MESSAGE);
            return -1; //indica erro
        }
        return -1;
    }
}
