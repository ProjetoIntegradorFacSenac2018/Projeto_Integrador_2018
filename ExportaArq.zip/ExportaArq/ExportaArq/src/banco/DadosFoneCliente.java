/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banco;

import ExportaArqs.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class DadosFoneCliente {
        public static int insereFoneClientes(Connection bdConnection, Cliente i) {
        if (bdConnection == null) {
            return -1;
        }
        PreparedStatement stmt = null;
        try {
            // prepara comando a ser executado pelo BD
            stmt = bdConnection.prepareStatement(
                    "INSERT INTO tb_fone (cod_cli, tp_fone, telefone) VALUES (?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, Integer.parseInt(i.getId_cliente()));
            stmt.setString(2, i.getTipo_fone1());
            stmt.setString(3, i.getFoneResid_cli());
            // executa comando
            stmt.executeUpdate();
            stmt.close();

            // prepara comando a ser executado pelo BD
            stmt = bdConnection.prepareStatement(
                    "INSERT INTO tb_fone (cod_cli, tp_fone, telefone) VALUES (?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, Integer.parseInt(i.getId_cliente()));
            stmt.setString(2, i.getTipo_fone2());
            stmt.setString(3, i.getFoneCial_cli());
            // executa comando
            stmt.executeUpdate();
              stmt.close();

            // prepara comando a ser executado pelo BD
            stmt = bdConnection.prepareStatement(
                    "INSERT INTO tb_fone (cod_cli, tp_fone, telefone) VALUES (?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, Integer.parseInt(i.getId_cliente()));
            stmt.setString(2, i.getTipo_fone3());
            stmt.setString(3, i.getFoneCelul_cli());
            // executa comando
            stmt.executeUpdate();
            stmt.close();
//            return id;

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao inserir Dados fone de clientes na base de dados\n" + ex.getMessage(),
                    "Inserir fone de clientes", JOptionPane.ERROR_MESSAGE);
            return -1; //indica erro
        }
        return -1;
    }

}
