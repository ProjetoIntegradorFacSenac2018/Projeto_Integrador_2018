
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banco;

import ExportaArqs.Venda;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;


public class DadosVendas {
        public static int insereVendas(Connection bdConnection, Venda i) {

        
            if (bdConnection == null) {
            return -1;
        }
        Date dtNF;
        PreparedStatement stmt = null;
        try {
            try
            {
                SimpleDateFormat formatter = new SimpleDateFormat("yyyymmdd");
                dtNF = formatter.parse(i.getData_nf());
            } catch (ParseException e) {
                JOptionPane.showMessageDialog(null,
                        "Erro ao inserir Dados de Vendas na base de dados\n" + e.getMessage(),
                        "Inserir dados de vendas", JOptionPane.ERROR_MESSAGE);
                return -1; //indica erro
            }            
            
            // prepara comando a ser executado pelo BD
            stmt = bdConnection.prepareStatement(
                    "INSERT INTO db_header (nr_nf, serie_nf, cod_cli, data_nf, cod_pg) VALUES (?, ?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, Integer.parseInt(i.getNr_nf()));
            stmt.setString(2, i.getSerie_nf());
            stmt.setInt(3, Integer.parseInt(i.getCod_cli()));
            stmt.setDate(4, new java.sql.Date(dtNF.getTime()));
            stmt.setString(5, i.getId_forma_pg());
            // executa comando
            stmt.executeUpdate();

            stmt.close();
//            return id;

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao inserir Dados de Vendas na base de dados\n" + ex.getMessage(),
                    "Inserir dados de vendas", JOptionPane.ERROR_MESSAGE);
            return -1; //indica erro
        }
        return -1;
    }
    
}
