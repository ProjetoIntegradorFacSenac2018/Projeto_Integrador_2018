/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banco;

import ExportaArqs.Produto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class DadosProdutos {

    public static int insereProduto(Connection bdConnection, Produto i) {

        if (bdConnection == null) {
            return -1;
        }
        PreparedStatement stmt = null;
        try {
            // prepara comando a ser executado pelo BD
            stmt = bdConnection.prepareStatement(
                    "INSERT INTO tb_produto (cod_prod, desc_prod, ean_13, un_vend_prod, preco_unit_prod) VALUES (?, ?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, Integer.parseInt(i.getId_produto()));
            stmt.setString(2, i.getDesc_prod());
            stmt.setString(3, i.getEan_13());
            stmt.setString(4, i.getUn_vend_prod());
            stmt.setDouble(5, Double.parseDouble(i.getPreco_unit_prod().trim().replaceAll(",", ".")));

            // executa comando
            stmt.executeUpdate();
            // obtem chave gerada para o registro inserido
//            int id = -1;
//            ResultSet rsID = stmt.getGeneratedKeys();
//            if (rsID.next()) {
//                id = rsID.getInt("id");
//            }
            stmt.close();
//            return id;

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,
                    "Erro ao inserir dados de produtos na base de dados\n" + ex.getMessage(),
                    "Inserir dados de produtos", JOptionPane.ERROR_MESSAGE);
            return -1; //indica erro
        }
        return -1;
    }
}
