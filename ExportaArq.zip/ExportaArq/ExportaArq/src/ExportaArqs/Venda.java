package ExportaArqs;

public class Venda {

    private String nr_nf;
    private String serie_nf;
    private String cod_cli;
    private String cpf_cli;
    private String data_nf;
    private String id_forma_pg;

    public Venda(String nr_nf, String serie_nf, String cod_cli, 
            String cpf_cli, String data_nf, String id_forma_pg) {

        this.nr_nf = nr_nf;
        this.serie_nf = serie_nf;
        this.cod_cli = cod_cli;
        this.cpf_cli = cpf_cli;
        this.data_nf = data_nf;
        this.id_forma_pg = id_forma_pg;
    }

    public String getNr_nf() {
        return nr_nf;
    }

    public void setNr_nf(String nr_nf) {
        this.nr_nf = nr_nf;
    }

    public String getSerie_nf() {
        return serie_nf;
    }

    public void setSerie_nf(String serie_nf) {
        this.serie_nf = serie_nf;
    }

    public String getData_nf() {
        return data_nf;
    }

    public String getCod_cli() {
        return cod_cli;
    }

    public void setCod_cli(String cod_cli) {
        this.cod_cli = cod_cli;
    }

    public void setData_nf(String data_nf) {
        this.data_nf = data_nf;
    }

    public String getId_forma_pg() {
        return id_forma_pg;
    }

    public void setId_forma_pg(String id_forma_pg) {
        this.id_forma_pg = id_forma_pg;
    }

    public String getCpf_cli() {
        return cpf_cli;
    }

    public void setCpf_cli(String cpf_cli) {
        this.cpf_cli = cpf_cli;
    }
}
