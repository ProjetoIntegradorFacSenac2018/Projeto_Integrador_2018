package ExportaArqs;

public class Unidade {

    private String un_vend_prod;
    private String desc_unid;

    public Unidade(String un_vend_prod, String desc_unid) {

        this.un_vend_prod = un_vend_prod;
        this.desc_unid = desc_unid;
    }

    public String getUn_vend_prod() {
        return un_vend_prod;
    }

    public void setUn_vend_prod(String un_vend_prod) {
        this.un_vend_prod = un_vend_prod;
    }

    public String getDesc_unid() {
        return desc_unid;
    }

    public void setDesc_unid(String desc_unid) {
        this.desc_unid = desc_unid;
    }

}
