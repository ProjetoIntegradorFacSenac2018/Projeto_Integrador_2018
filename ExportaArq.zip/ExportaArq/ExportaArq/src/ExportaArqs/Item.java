package ExportaArqs;

public class Item {

    private String nr_nf;
    private String id_produto;
    private String qtd_item;
    private String vlr_desc_item;

    public Item(String nr_nf, String id_produto, String qtd_item,
            String vlr_desc_item) {

        this.nr_nf = nr_nf;
        this.id_produto = id_produto;
        this.qtd_item = qtd_item;
        this.vlr_desc_item = vlr_desc_item;
    }

    public String getNr_nf() {
        return nr_nf;
    }

    public void setNr_nf(String nr_nf) {
        this.nr_nf = nr_nf;
    }

    public String getId_produto() {
        return id_produto;
    }

    public void setId_produto(String id_produto) {
        this.id_produto = id_produto;
    }

    public String getQtd_item() {
        return qtd_item;
    }

    public void setQtd_item(String qtd_item) {
        this.qtd_item = qtd_item;
    }

    public String getVlr_desc_item() {
        return vlr_desc_item;
    }

    public void setVlr_desc_item(String vlr_desc_item) {
        this.vlr_desc_item = vlr_desc_item;
    }

}
