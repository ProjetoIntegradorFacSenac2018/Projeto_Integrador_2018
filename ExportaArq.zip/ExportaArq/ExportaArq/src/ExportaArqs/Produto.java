/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ExportaArqs;

public class Produto {

    private String id_produto;
    private String desc_prod;
    private String ean_13;
    private String un_vend_prod;
    private String preco_unit_prod;

    public Produto(String id_produto, String desc_prod, String ean_13,
             String un_vend_prod, String preco_unit_prod) {
        this.id_produto = id_produto;
        this.desc_prod = desc_prod;
        this.ean_13 = ean_13;
        this.un_vend_prod = un_vend_prod;
        this.preco_unit_prod = preco_unit_prod;
    }

    public String getId_produto() {
        return id_produto;
    }

    public void setId_produto(String id_produto) {
        this.id_produto = id_produto;
    }

    public String getDesc_prod() {
        return desc_prod;
    }

    public void setDesc_prod(String desc_prod) {
        this.desc_prod = desc_prod;
    }

    public String getEan_13() {
        return ean_13;
    }

    public void setEan_13(String ean_13) {
        this.ean_13 = ean_13;
    }

    public String getPreco_unit_prod() {
        return preco_unit_prod;
    }

    public void setPreco_unit_prod(String preco_unit_prod) {
        this.preco_unit_prod = preco_unit_prod;
    }

    public String getUn_vend_prod() {
        return un_vend_prod;
    }

    public void setUn_vend_prod(String un_vend_prod) {
        this.un_vend_prod = un_vend_prod;
    }

}
