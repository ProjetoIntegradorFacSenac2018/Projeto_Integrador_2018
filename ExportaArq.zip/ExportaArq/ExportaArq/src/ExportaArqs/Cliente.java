/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ExportaArqs;

import java.util.ArrayList;

public class Cliente {

    private String id_cliente;
    private String nome_cli;
    private String cpf_cli;
    private String cep_cli;
    private String endereco_cli;
    private String tipo_fone1;
    private String foneResid_cli;
    private String tipo_fone2;
    private String foneCial_cli;
    private String tipo_fone3;
    private String foneCelul_cli;
    private String cidade_cli;
    private String uf_cli;

    public Cliente(String id_cliente, String nome_cli, String cpf_cli,
            String cep_cli, String endereco_cli, String tipo_fone1,
            String foneResid_cli, String tipo_fone2,
            String foneCial_cli, String tipo_fone3,
            String foneCelul_cli, String cidade_cli, String uf_cli) {
        this.id_cliente = id_cliente;
        this.nome_cli = nome_cli;
        this.cpf_cli = cpf_cli;
        this.cep_cli = cep_cli;
        this.endereco_cli = endereco_cli;
        this.tipo_fone1 = tipo_fone1;
        this.foneResid_cli = foneResid_cli;
        this.tipo_fone2 = tipo_fone2;
        this.foneCial_cli = foneCial_cli;
        this.tipo_fone3 = tipo_fone3;
        this.foneCelul_cli = foneCelul_cli;
        this.cidade_cli = cidade_cli;
        this.uf_cli = uf_cli;
    }

    public String getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(String id_cliente) {
        this.id_cliente = id_cliente;
    }

    public String getNome_cli() {
        return nome_cli;
    }

    public void setNome_cli(String nome_cli) {
        this.nome_cli = nome_cli;
    }

    public String getCpf_cli() {
        return cpf_cli;
    }

    public void setCpf_cli(String cpf_cli) {
        this.cpf_cli = cpf_cli;
    }

    public String getCep_cli() {
        return cep_cli;
    }

    public void setCep_cli(String cep_cli) {
        this.cep_cli = cep_cli;
    }

    public String getEndereco_cli() {
        return endereco_cli;
    }

    public void setEndereco_cli(String endereco_cli) {
        this.endereco_cli = endereco_cli;
    }

    public String getTipo_fone1() {
        return tipo_fone1;
    }

    public void setTipo_fone1(String tipo_fone1) {
        this.tipo_fone1 = tipo_fone1;
    }

    public String getFoneResid_cli() {
        return foneResid_cli;
    }

    public void setFoneResid_cli(String foneResid_cli) {
        this.foneResid_cli = foneResid_cli;
    }

    public String getTipo_fone2() {
        return tipo_fone2;
    }

    public void setTipo_fone2(String tipo_fone2) {
        this.tipo_fone2 = tipo_fone2;
    }

    public String getFoneCial_cli() {
        return foneCial_cli;
    }

    public void setFoneCial_cli(String foneCial_cli) {
        this.foneCial_cli = foneCial_cli;
    }

    public String getTipo_fone3() {
        return tipo_fone3;
    }

    public void setTipo_fone3(String tipo_fone3) {
        this.tipo_fone3 = tipo_fone3;
    }

    public String getFoneCelul_cli() {
        return foneCelul_cli;
    }

    public void setFoneCelul_cli(String foneCelul_cli) {
        this.foneCelul_cli = foneCelul_cli;
    }

    public String getCidade_cli() {
        return cidade_cli;
    }

    public void setCidade_cli(String cidade_cli) {
        this.cidade_cli = cidade_cli;
    }

    public String getUf_cli() {
        return uf_cli;
    }

    public void setUf_cli(String uf_cli) {
        this.uf_cli = uf_cli;
    }

}
