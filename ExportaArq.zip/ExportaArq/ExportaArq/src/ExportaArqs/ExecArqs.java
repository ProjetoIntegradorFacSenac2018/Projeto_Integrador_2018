/*
 * Exporta arquivo CSV para alimentar tabelas de projeto integrador
 */
package ExportaArqs;

import banco.DadosClientes;
import banco.DadosFoneCliente;
import banco.DadosFormaPgto;
import banco.MyPostgreSQL;
import banco.DadosItens;
import banco.DadosProdutos;
import banco.DadosUnidade;
import banco.DadosVendas;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.BufferedReader;
//import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
//import java.io.FileWriter;
import java.io.IOException;
//import java.text.DateFormat;
//import java.text.NumberFormat;
//import java.text.SimpleDateFormat;
//import java.util.Calendar;
//import java.util.Date;

public class ExecArqs {

//    private static boolean dadosAlterados = false;
    private static Scanner leia = new Scanner(System.in);

    private static ArrayList<Cliente> clientes = new ArrayList<Cliente>();
    final static private String NOME_ARQ_CLIENTES = "cliente.txt";

    private static ArrayList<Produto> produtos = new ArrayList<Produto>();
    final static private String NOME_ARQ_PRODUTOS = "produto.txt";

    private static ArrayList<Venda> vendas = new ArrayList<Venda>();
    final static private String NOME_ARQ_VENDAS = "venda.txt";

    private static ArrayList<Item> itens = new ArrayList<Item>();
    final static private String NOME_ARQ_ITENS = "item.txt";

    private static ArrayList<FormaPgto> formapgtos = new ArrayList<FormaPgto>();
    final static private String NOME_ARQ_FORMA_PGTO = "for_pgto.txt";

    private static MyPostgreSQL myBD;

    private static ArrayList<Unidade> unidades = new ArrayList<Unidade>();
    final static private String NOME_ARQ_UNIDADE = "unidade.txt";

    public static void main(String[] args) {
        // TODO Auto-generated method stub

        myBD = new MyPostgreSQL();
        if (myBD.conecta() == false) {
            System.out.println("Não foi possivel fazer conecção com bando de dados!");
        } else {

            // leitura do arquivo com os dados dos clientes já cadastrados
              lerCliente();
              lerUnidade();
              LerFormaPg();
              LerProduto();
              LerVenda();
              LerItem();

            myBD.encerra();
        }
    }

    private static void lerCliente() {
        File arquivo = new File(NOME_ARQ_CLIENTES);
        Cliente p;
        String linha;
        String[] vet;

        if (!arquivo.exists()) {
            System.out.println("Arquivo de dados de Cliente não existe!");
            return;
        }

        // limpar clientes
        clientes.clear();

        try {
            //faz a leitura do arquivo
            FileReader fr = new FileReader(arquivo);
            BufferedReader br = new BufferedReader(fr);

            // leitura dos dados dos clientes (enquanto houver linhas)
            while (br.ready()) {
                //lê a próxima linha
                linha = br.readLine();

                // verifica se linha é uma linha de dados
                if (linha.charAt(0) != '#') {
                    vet = linha.split(";");
                    p = new Cliente(vet[0], vet[1], vet[2], vet[3], vet[4],
                            vet[5], vet[6], vet[7], vet[8], vet[9],
                            vet[10], vet[11], vet[12]);
                    clientes.add(p);
                    DadosClientes.insereClientes(myBD.getConnection(), p);
                    DadosFoneCliente.insereFoneClientes(myBD.getConnection(), p);
                }
            }
            br.close();
            fr.close();

            System.out.println("Dados de Clientes lidos com sucesso!");
            System.out.println("Total de Clientes  lidos: " + clientes.size());

        } catch (IOException ex) {
            System.out.println("ERRO: leitura do arquivo de dados de Clientes!");
        }
    }

    private static void lerUnidade() {
        // TODO Auto-generated method stub
        File arquivo = new File(NOME_ARQ_UNIDADE);
        Unidade p;
        String linha;
        String[] vet;

        if (!arquivo.exists()) {
            System.out.println("Arquivo de dados de Unidade Vendas não existe!");
            return;
        }

        // limpar Unidades de vendas
        unidades.clear();

        try {
            //faz a leitura do arquivo
            FileReader fr = new FileReader(arquivo);
            BufferedReader br = new BufferedReader(fr);

            // leitura dos dados de Unidades de vendas (enquanto houver linhas)
            while (br.ready()) {
                //lê a próxima linha
                linha = br.readLine();

                // verifica se linha é uma linha de dados
                if (linha.charAt(0) != '#') {
                    vet = linha.split(";");
                    p = new Unidade(vet[0], vet[1]);
                    unidades.add(p);
                    DadosUnidade.insereUnidade(myBD.getConnection(), p);
                }
            }

            br.close();
            fr.close();

            System.out.println("Dados de Unidade de Vendas lidos com sucesso!");
            System.out.println("Total de Unidade de Vendas  lidos: " + unidades.size());

        } catch (IOException ex) {
            System.out.println("ERRO: leitura do arquivo de dados de Unidade de Vendas!");
        }
    }

    private static void LerFormaPg() {
        // TODO Auto-generated method stub
        File arquivo = new File(NOME_ARQ_FORMA_PGTO);
        FormaPgto p;
        String linha;
        String[] vet;

        if (!arquivo.exists()) {
            System.out.println("Arquivo de dados de Forma Pgto não existe!");
            return;
        }

        // limpar de Forma Pgto
        formapgtos.clear();

        try {
            //faz a leitura do arquivo
            FileReader fr = new FileReader(arquivo);
            BufferedReader br = new BufferedReader(fr);

            // leitura dos dados de Forma Pgto (enquanto houver linhas)
            while (br.ready()) {
                //lê a próxima linha
                linha = br.readLine();

                // verifica se linha é uma linha de dados
                if (linha.charAt(0) != '#') {
                    vet = linha.split(";");
                    p = new FormaPgto(vet[0], vet[1]);
                    formapgtos.add(p);
                    DadosFormaPgto.insereFormaPgto(myBD.getConnection(), p);
                }
            }

            br.close();
            fr.close();

            System.out.println("Dados de Forma Pgto lidos com sucesso!");
            System.out.println("Total de Forma Pgto lidos: " + formapgtos.size());

        } catch (IOException ex) {
            System.out.println("ERRO: leitura do arquivo de dados de Forma Pgto!");
        }
    }

    private static void LerProduto() {
        // TODO Auto-generated method stub
        File arquivo = new File(NOME_ARQ_PRODUTOS);
        Produto p;
        String linha;
        String[] vet;

        if (!arquivo.exists()) {
            System.out.println("Arquivo de dados de Produto não existe!");
            return;
        }

        // limpar produtos
        produtos.clear();

        try {
            //faz a leitura do arquivo
            FileReader fr = new FileReader(arquivo);
            BufferedReader br = new BufferedReader(fr);

            // leitura dos dados dos produtos (enquanto houver linhas)
            while (br.ready()) {
                //lê a próxima linha
                linha = br.readLine();

                // verifica se linha é uma linha de dados
                if (linha.charAt(0) != '#') {
                    vet = linha.split(";");
                    p = new Produto(vet[0], vet[1], vet[2], vet[3], vet[4]);
                    produtos.add(p);
                    DadosProdutos.insereProduto(myBD.getConnection(), p);
                }
            }

            br.close();
            fr.close();

            System.out.println("Dados de Produtos lidos com sucesso!");
            System.out.println("Total de Produtos  lidos: " + produtos.size());

        } catch (IOException ex) {
            System.out.println("ERRO: leitura do arquivo de dados de Produtos!");
        }

    }

    private static void LerVenda() {
        // TODO Auto-generated method stub
        File arquivo = new File(NOME_ARQ_VENDAS);
        Venda p;
        String linha;
        String[] vet;

        if (!arquivo.exists()) {
            System.out.println("Arquivo de dados de Vendas não existe!");
            return;
        }

        // limpar vendas
        vendas.clear();

        try {
            //faz a leitura do arquivo
            FileReader fr = new FileReader(arquivo);
            BufferedReader br = new BufferedReader(fr);

            // leitura dos dados de Vendas (enquanto houver linhas)
            while (br.ready()) {
                //lê a próxima linha
                linha = br.readLine();

                // verifica se linha é uma linha de dados
                if (linha.charAt(0) != '#') {
                    vet = linha.split(";");
                    p = new Venda(vet[0], vet[1], vet[2], vet[3], vet[4], vet[5]);
                    vendas.add(p);
                    DadosVendas.insereVendas(myBD.getConnection(), p);
                }
            }

            br.close();
            fr.close();

            System.out.println("Dados de Vendas lidos com sucesso!");
            System.out.println("Total de Vendas  lidos: " + vendas.size());

        } catch (IOException ex) {
            System.out.println("ERRO: leitura do arquivo de dados de Vendas!");
        }
    }

    private static void LerItem() {
        // TODO Auto-generated method stub
        File arquivo = new File(NOME_ARQ_ITENS);
        Item p;
        String linha;
        String[] vet;

        if (!arquivo.exists()) {
            System.out.println("Arquivo de dados de Vendas não existe!");
            return;
        }

        // limpar itens de vendas
        itens.clear();

        try {
            //faz a leitura do arquivo
            FileReader fr = new FileReader(arquivo);
            BufferedReader br = new BufferedReader(fr);

            // leitura dos dados de Itens de Vendas (enquanto houver linhas)
            while (br.ready()) {
                //lê a próxima linha
                linha = br.readLine();

                // verifica se linha é uma linha de dados
                if (linha.charAt(0) != '#') {
                    vet = linha.split(";");
                    p = new Item(vet[0], vet[1], vet[2], vet[3]);
                    itens.add(p);

                    DadosItens.insereItem(myBD.getConnection(), p);
                }
            }

            br.close();
            fr.close();

            System.out.println("Dados de Itens de Vendas lidos com sucesso!");
            System.out.println("Total de Itens de Vendas  lidos: " + itens.size());

        } catch (IOException ex) {
            System.out.println("ERRO: leitura do arquivo de dados de Itens de Vendas!");
        }
    }
}
