package ExportaArqs;

public class FormaPgto {

    private String id_forma_pg;
    private String desc_forma_pg;

    public FormaPgto(String id_forma_pg, String desc_forma_pg) {

        this.id_forma_pg = id_forma_pg;
        this.desc_forma_pg = desc_forma_pg;
    }

    public String getId_forma_pg() {
        return id_forma_pg;
    }

    public void setId_forma_pg(String id_forma_pg) {
        this.id_forma_pg = id_forma_pg;
    }

    public String getDesc_forma_pg() {
        return desc_forma_pg;
    }

    public void setDesc_forma_pg(String desc_forma_pg) {
        this.desc_forma_pg = desc_forma_pg;
    }

}
