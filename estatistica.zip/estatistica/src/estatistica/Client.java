package br.com.senac.estatistica;

public class Client {

	public static void main(String[] args) {
		// Instancia a classe utilit�ria
		Estatistica e = new Estatistica();

		// seta valores do array
		double array[] = { 1, 46, 49, 51, 54, 54, 59, 59, 60, 60, 61, 61, 62, 65, 66, 66, 
				           67, 67, 69, 70, 70, 71, 72, 74, 74, 76, 79, 80, 82, 87, 88 };

		// para teste com 700000 mil valores,
		//array = new double[700000];
		//Arrays.fill(array, 999);

		e.setArray(array);

		// Marca o in�cio do tempo
		double t1 = System.currentTimeMillis();

		// e.imprimeArray(); ////Cuidado com esta linha, pois se o array tiver
		// milhoes de valores seu console vai encher
		// System.out.print("\n"+e.buscaPor(9));
		System.out.print("\n mediana: " + e.getMediana());
		System.out.print("\n Soma Elementos: " + e.getSomaDosElementos());
		System.out.print("\n Media Aritm�tica: " + e.getMediaAritmetica());
		System.out.print("\n SomaDosElementosAoQuadrado: "
				+ e.getSomaDosElementosAoQuadrado());
		System.out.print("\n Vari�ncia Amostral: " + e.getVariancia());
		System.out.print("\n Desvio Padr�o: " + e.getDesvioPadrao());
		System.out.print("\n Coeficiente Varia��o de Pearson: "
				+ e.getPearson());
		System.out.print("\n Moda: " + e.getModa());
		System.out.print("\n Coeficiente de Assimetria: "
				+ e.getCoefAssimetria());

		// marca o fim do processamento
		double t2 = System.currentTimeMillis();

		// exibe o tempo em segundos
		System.out.print("\n Tempo Total: " + (t2 - t1) / Double.valueOf(1000)
				+ " segundos");
	}
}
